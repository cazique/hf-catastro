# 🏠 Sistema Catastral — Hogar Familiar
... (ver README completo en el repo; contiene instrucciones, limitaciones y roadmap)
